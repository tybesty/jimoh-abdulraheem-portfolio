# Jimoh Abdulraheem — Developer Portfolio Starter

A responsive, single-page portfolio website starter for a WordPress and full-stack web developer.

## Files
- `index.html` — page content and sections
- `style.css` — responsive styling
- `script.js` — mobile navigation and footer year

## Run locally
Open `index.html` in a browser. No build tools are required.

## Publish with GitHub Pages
1. Create or sign in to a GitHub account.
2. Create a public repository named `jimoh-abdulraheem-portfolio`.
3. Upload `index.html`, `style.css`, `script.js`, and this README.
4. In the repository, open **Settings → Pages**.
5. Under Build and deployment, select **Deploy from a branch**, choose `main` and `/ (root)`, then save.
6. Wait for GitHub Pages to publish the site. Copy the published URL into your CV.

## Important portfolio honesty note
The three project cards on the website are clearly marked **DEMO TO BUILD**. They are project briefs, not claims of completed client work. Replace each brief only after you have built and tested the project. Add screenshots, a live demo URL, a repository URL, your role, and the technologies used.

## Before publishing
- Confirm your contact details.
- Add only skills you can demonstrate.
- Add screenshots of genuine work after building it.
- Test the site on a phone and desktop.
